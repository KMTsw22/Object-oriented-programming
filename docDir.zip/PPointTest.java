package docDir;
import docDir.PPoint;
/*
    @param this param is empty
    @return ppoint is return X + Y
*/
public class PPointTest {
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}