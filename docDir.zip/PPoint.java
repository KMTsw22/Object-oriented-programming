package docDir;
/*
    @param this param is x , y
    @return ppoint is return X, Y
*/

public class PPoint {
    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    public int getX() {
        return xA;
    }
    public int getY() {
        return yA;
    }
}
